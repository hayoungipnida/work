<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // [1] HTML 폼태그(register.php)에서 넘어오는 name 값들 수집
    $lastNameEng  = htmlspecialchars(trim($_POST['last_name_eng'] ?? ''));
    $firstNameEng = htmlspecialchars(trim($_POST['first_name_eng'] ?? ''));
    $lastNameKor  = htmlspecialchars(trim($_POST['last_name_kor'] ?? ''));
    $firstNameKor = htmlspecialchars(trim($_POST['first_name_kor'] ?? ''));
    $birthDate    = htmlspecialchars(trim($_POST['birth_date'] ?? ''));
    $gender       = htmlspecialchars(trim($_POST['gender'] ?? ''));
    
    $userId       = htmlspecialchars(trim($_POST['user_id'] ?? ''));
    $userPw       = htmlspecialchars(trim($_POST['user_pw'] ?? ''));
    $phone        = htmlspecialchars(trim($_POST['phone'] ?? ''));
    $email        = htmlspecialchars(trim($_POST['email'] ?? ''));
    $address      = htmlspecialchars(trim($_POST['address'] ?? ''));
    
    // 약관 동의 값 (체크 안 되면 N, 체크 되면 Y)
    $reqAgree1    = isset($_POST['agree_required_1']) ? 'Y' : 'N';
    $reqAgree2    = isset($_POST['agree_required_2']) ? 'Y' : 'N';
    $reqAgree3    = isset($_POST['agree_required_3']) ? 'Y' : 'N';
    $optAgree1    = isset($_POST['agree_optional_1']) ? 'Y' : 'N';
    $optAgree2    = isset($_POST['agree_optional_2']) ? 'Y' : 'N';

    // [2] 데이터베이스 연결 (본인의 DB명 입력)
    $db_host = "localhost";
    $db_user = "gnuoyah";
    $db_pass = "wjdgkdud1!";
    $db_name = "gnuoyah"; 

    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    if (!$conn) {
        die("DB 연결 실패: " . mysqli_connect_error());
    }

    // [3] 비밀번호 보안 암호화 (members 테이블의 user_pw 공간에 저장용)
    $hashedPassword = password_hash($userPw, PASSWORD_DEFAULT);

    // [4] 안전한 저장을 위한 트랜잭션(Transaction) 시작
    // 회원 테이블과 약관 테이블 둘 다 안전하게 성공해야만 최종 반영되게 합니다.
    mysqli_begin_transaction($conn);

    try {
        // SQL 1. 질문자님의 members 테이블 컬럼명 명세에 정확히 맞춘 쿼리
        $sql1 = "INSERT INTO members (
                    user_id, user_pw, last_name_eng, first_name_eng, 
                    last_name_kor, first_name_kor, birth_date, gender, 
                    phone, email, address
                 ) VALUES (
                    '$userId', '$hashedPassword', '$lastNameEng', '$firstNameEng', 
                    '$lastNameKor', '$firstNameKor', '$birthDate', '$gender', 
                    '$phone', '$email', '$address'
                 )";
                 
        if (!mysqli_query($conn, $sql1)) {
            throw new Exception("members 테이블 저장 실패: " . mysqli_error($conn));
        }

        // 방금 members 테이블에 생성되면서 부여된 AI 고유 번호(member_idx) 알아내기
        $newMemberIdx = mysqli_insert_id($conn);

        // SQL 2. 질문자님의 member_terms 테이블 컬럼명 명세에 정확히 맞춘 쿼리
        $sql2 = "INSERT INTO member_terms (
                    member_idx, agree_required_1, agree_required_2, agree_required_3, 
                    agree_optional_1, agree_optional_2
                 ) VALUES (
                    $newMemberIdx, '$reqAgree1', '$reqAgree2', '$reqAgree3', 
                    '$optAgree1', '$optAgree2'
                 )";

        if (!mysqli_query($conn, $sql2)) {
            throw new Exception("member_terms 테이블 저장 실패: " . mysqli_error($conn));
        }

        // 두 군데 모두 성공했으므로 DB에 최종 승인 커밋!
        mysqli_commit($conn);
        
        echo "<script>
                alert('회원가입이 성공적으로 완료되었습니다!'); 
                location.href='index.html';
              </script>";

    } catch (Exception $e) {
        // 데이터 입력 중 하나라도 삐끗하면 롤백하여 깨끗하게 취소 처리
        mysqli_rollback($conn);
        
        // 어떤 테이블의 무슨 컬럼 때문에 에러가 났는지 브라우저 화면에 에러를 상세히 찍어줍니다.
        echo "<div style='color: red; padding: 20px; border: 1px solid red; margin: 20px;'>";
        echo "<h3>❌ DB 저장 실패 (SQL 에러 발생)</h3>";
        echo "<p><b>원인:</b> " . $e->getMessage() . "</p>";
        echo "<p>팁: 테이블 컬럼명과 PHP 쿼리 속 스펠링이 완벽히 일치하는지 확인해 보세요.</p>";
        echo "</div>";
    }

    // DB 연결 닫기
    mysqli_close($conn);

} else {
    header("Location: register.php");
    exit;
}
?>