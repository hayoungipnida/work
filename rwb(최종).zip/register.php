<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>회원가입</title>
  <link rel="stylesheet" href="css/reset.css">
  <link rel="stylesheet" href="css/register.css">
</head>
<body>
  <div class="register-container">
    <header class="register-header">
      <h1 class="logo"><a href="index.php"><img src="img/logo_m.png" alt="logo"></a></h1>
      <h2 class="title">회원가입</h2>
      <p class="notice"><span class="required">*</span>는 필수 입력 사항입니다.</p>
    </header>

     <form class="register-form" id="regForm" action="register_process.php" method="POST">

      <!-- STEP 1 비활성 라벨 (step1 완료 후 보임) -->
      <section id="step1_label" class="step-box disabled" style="display:none;">
        <div class="step-title">
          <span class="icon"><img src="img/unactive1.png" alt="icon"></span>
          <h3>기본 정보</h3>
        </div>
      </section>

      <!-- STEP 1 폼 -->
      <section id="step1" class="step-box active">
        <div class="step-title">
          <span class="icon" id="step1_icon"><img src="img/active1.png" alt="icon"></span>
          <h3>기본정보</h3>
        </div>
        <p class="step-desc">개인정보를 입력해주세요</p>

        <div class="input-group">
          <label for="last_name_eng">영문 성 <span class="required">*</span></label>
          <p class="input-hint">특수 문자 제외하여 여권과 동일한 철자로 입력해주세요</p>
          <input type="text" id="last_name_eng" name="last_name_eng" placeholder="예) KIM">
        </div>
        <div class="input-group">
          <label for="first_name_eng">영문 이름 <span class="required">*</span></label>
          <p class="input-hint">특수 문자 제외하여 여권과 동일한 철자로 입력해주세요</p>
          <input type="text" id="first_name_eng" name="first_name_eng" placeholder="예) HANKUK">
        </div>
        <div class="input-group">
          <label for="last_name_kor">한글 성 <span class="required">*</span></label>
          <input type="text" id="last_name_kor" name="last_name_kor" placeholder="예) 김">
        </div>
        <div class="input-group">
          <label for="first_name_kor">한글 이름 <span class="required">*</span></label>
          <input type="text" id="first_name_kor" name="first_name_kor" placeholder="예) 한국">
        </div>
        <div class="input-group">
          <label for="birth_date">생년월일 <span class="required">*</span></label>
          <input type="text" id="birth_date" name="birth_date" placeholder="예) 19900101">
        </div>
        <div class="input-group">
          <label>성별 선택 <span class="required">*</span></label>
          <div class="radio-group">
            <label class="radio-label">
              <input type="radio" name="gender" value="M" checked>
              <span class="custom-radio"></span> 남자
            </label>
            <label class="radio-label">
              <input type="radio" name="gender" value="F">
              <span class="custom-radio"></span> 여자
            </label>
          </div>
        </div>

        <div class="btn-area">
          <button type="button" class="next-btn" id="step1_next" onclick="goToStep(2)" disabled>다음</button>
        </div>
      </section>

      <!-- STEP 2 비활성 라벨 -->
      <section id="step2_label" class="step-box disabled">
        <div class="step-title">
          <span class="icon"><img src="img/unactive2.png" alt="icon"></span>
          <h3>계정 및 연락처 정보</h3>
        </div>
      </section>

      <!-- STEP 2 폼 (숨김) -->
      <section id="step2" class="step-box" style="display:none;">
        <div class="step-title">
          <span class="icon"><img src="img/active2.png" alt="icon"></span>
          <h3>계정 및 연락처 정보</h3>
        </div>
        <p class="step-desc">사용하실 아이디와 비밀번호, 연락처를 입력해 주세요</p>

        <div class="input-group">
          <label>아이디 <span class="required">*</span></label>
          <p class="input-hint">6~12자리 영문, 숫자로 입력</p>
          <div class="input-with-btn">
            <input type="text" id="user_id" name="user_id" placeholder="아이디 입력">
            <button type="button" class="inline-btn" onclick="checkIdDup()">중복 확인</button>
          </div>
        </div>
        <div class="input-group">
          <label>비밀번호 <span class="required">*</span></label>
          <p class="input-hint">영문+숫자+특수문자(@~!#$%^&*()-=+,_?) 8자~20자 이내</p>
          <input type="password" id="user_pw" name="user_pw" placeholder="비밀번호 입력">
        </div>
        <div class="input-group">
          <label>비밀번호 확인 <span class="required">*</span></label>
          <input type="password" id="user_pw_confirm" name="user_pw_confirm" placeholder="비밀번호 재입력">
        </div>
        <div class="input-group">
          <label>휴대전화 번호 <span class="required">*</span></label>
          <input type="text" id="phone" name="phone" placeholder="예) 010-1234-5678">
        </div>
        <div class="input-group">
          <label>이메일 주소 <span class="required">*</span></label>
          <input type="text" id="email" name="email" placeholder="예) abc@asiana.com">
        </div>
        <div class="input-group">
          <label>거주국가 주소 <span class="required">*</span></label>
          <input type="text" id="address" name="address" placeholder="예) 대한민국 서울특별시">
        </div>

        <div class="btn-area split">
          <button type="button" class="prev-btn" onclick="goToStep(1)">이전</button>
          <button type="button" class="next-btn" id="step2_next" onclick="goToStep(3)" disabled>다음</button>
        </div>
      </section>

      <!-- STEP 2 완료 비활성 라벨 (step2 완료 후 보임) -->
      <section id="step2_done" class="step-box disabled" style="display:none;">
        <div class="step-title">
          <span class="icon"><img src="img/unactive2.png" alt="icon"></span>
          <h3>계정 및 연락처 정보</h3>
        </div>
      </section>

      <!-- STEP 3 비활성 라벨 -->
      <section id="step3_label" class="step-box disabled">
        <div class="step-title">
          <span class="icon"><img src="img/unactive3.png" alt="icon"></span>
          <h3>약관 동의</h3>
        </div>
      </section>

      <!-- STEP 3 폼 (숨김) -->
      <section id="step3" class="step-box" style="display:none;">
        <div class="step-title">
          <span class="icon"><img src="img/active3.png" alt="icon"></span>
          <h3>약관동의</h3>
        </div>
        <p class="step-desc">약관 및 정보이용 안내에 동의해 주세요</p>

        <div class="terms-container">
          <div class="terms-row all-check">
            <label class="checkbox-label">
              <input type="checkbox" id="all_agree" onclick="toggleAllTerms(this)">
              <span class="custom-checkbox"></span>
              <strong>필수 및 선택 약관에 모두 동의합니다.</strong>
            </label>
          </div>
          <div class="terms-row">
            <label class="checkbox-label">
              <input type="checkbox" name="agree_required_1" class="term-item" value="Y">
              <span class="custom-checkbox"></span>
              <span>[필수] 아시아나클럽 일반 규정 및 홈페이지 이용 약관</span>
            </label>
            <span class="arrow-icon">›</span>
          </div>
          <div class="terms-row">
            <label class="checkbox-label">
              <input type="checkbox" name="agree_required_2" class="term-item" value="Y">
              <span class="custom-checkbox"></span>
              <span>[필수] 개인정보 수집 및 이용안내</span>
            </label>
            <span class="arrow-icon">›</span>
          </div>
          <div class="terms-row">
            <label class="checkbox-label">
              <input type="checkbox" name="agree_required_3" class="term-item" value="Y">
              <span class="custom-checkbox"></span>
              <span>[필수] 개인정보 국외 이전 동의</span>
            </label>
            <span class="arrow-icon">›</span>
          </div>
          <div class="terms-row">
            <label class="checkbox-label">
              <input type="checkbox" name="agree_optional_1" class="term-item" value="Y">
              <span class="custom-checkbox"></span>
              <span>[선택] 마케팅 광고 활용 동의</span>
            </label>
            <span class="arrow-icon">›</span>
          </div>
          <div class="terms-row">
            <label class="checkbox-label">
              <input type="checkbox" name="agree_optional_2" class="term-item" value="Y">
              <span class="custom-checkbox"></span>
              <span>[선택] 개인정보 제 3자 제공 동의</span>
            </label>
            <span class="arrow-icon">›</span>
          </div>
          <div class="terms-info-box">
            <p>1. 아시아나항공은 별도의 회원동의 없이 개인정보를 제 3자에게 제공하지 않습니다.<br><strong>>> 제휴사 상세 보기</strong></p>
            <p style="margin-top:10px;">2. 선택정보 제공 동의 거부 시 일부 서비스가 제한됩니다.</p>
          </div>
        </div>

        <div class="btn-area split">
          <button type="button" class="prev-btn" onclick="goToStep('back2')">이전</button>
          <button type="submit" class="submit-btn">가입 완료</button>
        </div>
      </section>

    </form>
  </div>
  <script src="js/register.js"></script>
</body>
</html>