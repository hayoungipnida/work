<? 


/*mysqli_connect("localhost", "db아이디", "db비밀번호", "db명") or
die("SQL server에 연결할 수 없습니다.");

mysqli_select_db(connect,"db명");

이렇게 작성하면 됨*/


$connect=mysqli_connect("dothome", "gnouyah", "wjdgkdud1!", "gnouyah") or
die("SQL server에 연결할 수 없습니다.");

mysqli_select_db(connect,"gnouyah");
?>

