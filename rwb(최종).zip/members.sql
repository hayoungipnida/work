CREATE TABLE members (
    member_idx INT AUTO_INCREMENT PRIMARY KEY COMMENT '회원 고유 번호',
    user_id VARCHAR(20) NOT NULL UNIQUE COMMENT '사용자 아이디',
    user_pw VARCHAR(255) NOT NULL COMMENT '암호화된 비밀번호',
    
    last_name_eng VARCHAR(50) NOT NULL COMMENT '영문 성',
    first_name_eng VARCHAR(50) NOT NULL COMMENT '영문 이름',
    last_name_kor VARCHAR(30) NOT NULL COMMENT '한글 성',
    first_name_kor VARCHAR(50) NOT NULL COMMENT '한글 이름',
    
    birth_date VARCHAR(20) NOT NULL COMMENT '생년월일 (예: 1995-01-01)',
    gender CHAR(1) NOT NULL COMMENT '성별 (M: 남, F: 여)',
    
    phone VARCHAR(20) NOT NULL COMMENT '휴대전화 번호',
    email VARCHAR(100) NOT NULL COMMENT '이메일 주소',
    address VARCHAR(255) NOT NULL COMMENT '거주국가 주소',
    
    reg_date DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '가입일시'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2. 약관 동의 내역 테이블 (회원 번호와 매핑)
CREATE TABLE member_terms (
    term_idx INT AUTO_INCREMENT PRIMARY KEY COMMENT '로그 고유 번호',
    member_idx INT NOT NULL COMMENT '회원 고유 번호 (members 테이블 참조)',
    
    agree_required_1 CHAR(1) DEFAULT 'N' COMMENT '홈페이지 이용약관 동의 (Y/N)',
    agree_required_2 CHAR(1) DEFAULT 'N' COMMENT '개인정보 수집이용 동의 (Y/N)',
    agree_required_3 CHAR(1) DEFAULT 'N' COMMENT '개인정보 국외이전 동의 (Y/N)',
    agree_optional_1 CHAR(1) DEFAULT 'N' COMMENT '마케팅 광고 활용 동의 (Y/N)',
    agree_optional_2 CHAR(1) DEFAULT 'N' COMMENT '개인정보 제3자 제공 동의 (Y/N)',
    
    agree_date DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '동의 변경 일시',
    FOREIGN KEY (member_idx) REFERENCES members(member_idx) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;