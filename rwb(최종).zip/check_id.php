<?php
// 데이터베이스 연결
$db_host = "localhost";
$db_user = "gnuoyah";
$db_pass = "wjdgkdud1!";
$db_name = "gnuoyah"; 

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die(json_encode(array("result" => "error", "message" => "DB 연결 실패")));
}

// GET 방식으로 넘어온 아이디 받기
$userId = trim($_GET['user_id'] ?? '');

if (empty($userId)) {
    echo json_encode(array("result" => "empty"));
    exit;
}

$userId = mysqli_real_escape_string($conn, $userId);

// DB에 해당 아이디가 있는지 카운트
$sql = "SELECT COUNT(*) as cnt FROM members WHERE user_id = '$userId'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

// 결과를 JSON 형태로 자바스크립트에게 돌려줌
if ($row['cnt'] > 0) {
    echo json_encode(array("result" => "fail")); // 이미 존재하는 아이디
} else {
    echo json_encode(array("result" => "success")); // 사용 가능한 아이디
}

mysqli_close($conn);
?>