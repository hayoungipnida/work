function showError(inputId, message) {
    const input = document.getElementById(inputId);
    if (input) {
        input.classList.add('input-error');
        input.focus();
    }
    alert(message);
}

function clearErrors() {
    document.querySelectorAll('.input-error').forEach(el => el.classList.remove('input-error'));
}

// step1 버튼 활성화 체크
function checkStep1Ready() {
    const a = document.getElementById('last_name_eng').value.trim();
    const b = document.getElementById('first_name_eng').value.trim();
    const c = document.getElementById('last_name_kor').value.trim();
    const d = document.getElementById('first_name_kor').value.trim();
    const e = document.getElementById('birth_date').value.trim();
    const btn = document.getElementById('step1_next');
    btn.disabled = !(a && b && c && d && e);
}

// step2 버튼 활성화 체크
function checkStep2Ready() {
    const a = document.getElementById('user_id').value.trim();
    const b = document.getElementById('user_pw').value.trim();
    const c = document.getElementById('user_pw_confirm').value.trim();
    const d = document.getElementById('phone').value.trim();
    const e = document.getElementById('email').value.trim();
    const f = document.getElementById('address').value.trim();
    const btn = document.getElementById('step2_next');
    btn.disabled = !(a && b && c && d && e && f);
}

function goToStep(stepNumber) {
    clearErrors();

    if (stepNumber === 2) {
        const lastNameEng = document.getElementById('last_name_eng').value.trim();
        const firstNameEng = document.getElementById('first_name_eng').value.trim();
        const lastNameKor = document.getElementById('last_name_kor').value.trim();
        const firstNameKor = document.getElementById('first_name_kor').value.trim();
        const birthDate = document.getElementById('birth_date').value.trim();

        if (!lastNameEng) { showError('last_name_eng', '영문 성을 입력해주세요.'); return; }
        if (!/^[A-Z]+$/.test(lastNameEng)) { showError('last_name_eng', '영문 성은 대문자 영문만 입력 가능합니다.'); return; }
        if (!firstNameEng) { showError('first_name_eng', '영문 이름을 입력해주세요.'); return; }
        if (!/^[A-Z]+$/.test(firstNameEng)) { showError('first_name_eng', '영문 이름은 대문자 영문만 입력 가능합니다.'); return; }
        if (!lastNameKor) { showError('last_name_kor', '한글 성을 입력해주세요.'); return; }
        if (!/^[가-힣]+$/.test(lastNameKor)) { showError('last_name_kor', '한글 성은 한글만 입력 가능합니다.'); return; }
        if (!firstNameKor) { showError('first_name_kor', '한글 이름을 입력해주세요.'); return; }
        if (!/^[가-힣]+$/.test(firstNameKor)) { showError('first_name_kor', '한글 이름은 한글만 입력 가능합니다.'); return; }
        if (!birthDate) { showError('birth_date', '생년월일을 입력해주세요.'); return; }

        document.getElementById('step1').style.display = 'none';
        document.getElementById('step1_label').style.display = 'block';
        document.getElementById('step2_label').style.display = 'none';
        document.getElementById('step2').style.display = 'block';
        document.getElementById('step2').scrollIntoView({ behavior: 'smooth' });
    }

    else if (stepNumber === 3) {
        const userId = document.getElementById('user_id').value.trim();
        const userPw = document.getElementById('user_pw').value.trim();
        const userPwConfirm = document.getElementById('user_pw_confirm').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const email = document.getElementById('email').value.trim();
        const address = document.getElementById('address').value.trim();

        if (!userId) { showError('user_id', '아이디를 입력해주세요.'); return; }
        if (!/^[A-Za-z0-9]{6,12}$/.test(userId)) { showError('user_id', '아이디는 6~12자리 영문, 숫자만 입력 가능합니다.'); return; }
        if (!userPw) { showError('user_pw', '비밀번호를 입력해주세요.'); return; }
        if (!/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@~!#$%^&*()\-=+,_?]).{8,20}$/.test(userPw)) {
            showError('user_pw', '비밀번호는 영문+숫자+특수문자 조합 8~20자로 입력해주세요.'); return;
        }
        if (!userPwConfirm) { showError('user_pw_confirm', '비밀번호 확인을 입력해주세요.'); return; }
        if (userPw !== userPwConfirm) { showError('user_pw_confirm', '비밀번호가 일치하지 않습니다.'); return; }
        if (!phone) { showError('phone', '휴대전화 번호를 입력해주세요.'); return; }
        if (!email) { showError('email', '이메일 주소를 입력해주세요.'); return; }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showError('email', '올바른 이메일 형식으로 입력해주세요.'); return; }
        if (!address) { showError('address', '거주국가 주소를 입력해주세요.'); return; }

        document.getElementById('step2').style.display = 'none';
        document.getElementById('step2_done').style.display = 'block';
        document.getElementById('step3_label').style.display = 'none';
        document.getElementById('step3').style.display = 'block';
        document.getElementById('step3').scrollIntoView({ behavior: 'smooth' });
    }

    else if (stepNumber === 1) {
        document.getElementById('step2').style.display = 'none';
        document.getElementById('step1_label').style.display = 'none';
        document.getElementById('step1').style.display = 'block';
        document.getElementById('step2_label').style.display = 'block';
        document.getElementById('step1').scrollIntoView({ behavior: 'smooth' });
    }

    else if (stepNumber === 'back2') {
        document.getElementById('step3').style.display = 'none';
        document.getElementById('step2_done').style.display = 'none';
        document.getElementById('step2').style.display = 'block';
        document.getElementById('step3_label').style.display = 'block';
        document.getElementById('step2').scrollIntoView({ behavior: 'smooth' });
    }
}

function toggleAllTerms(mainCheckbox) {
    document.querySelectorAll('.term-item').forEach(cb => { cb.checked = mainCheckbox.checked; });
}

document.addEventListener('DOMContentLoaded', function() {

    // 영문 자동 대문자 + 영문만
    document.getElementById('last_name_eng').addEventListener('input', function() {
        this.value = this.value.toUpperCase().replace(/[^A-Z]/g, '');
        checkStep1Ready();
    });
    document.getElementById('first_name_eng').addEventListener('input', function() {
        this.value = this.value.toUpperCase().replace(/[^A-Z]/g, '');
        checkStep1Ready();
    });

    // 한글만
    document.getElementById('last_name_kor').addEventListener('input', function() {
        this.value = this.value.replace(/[^가-힣]/g, '');
        checkStep1Ready();
    });
    document.getElementById('first_name_kor').addEventListener('input', function() {
        this.value = this.value.replace(/[^가-힣]/g, '');
        checkStep1Ready();
    });

    // 생년월일 숫자만
    document.getElementById('birth_date').addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
        checkStep1Ready();
    });

    // step2 필드 변경 감지
    ['user_id', 'user_pw', 'user_pw_confirm', 'phone', 'email', 'address'].forEach(id => {
        document.getElementById(id).addEventListener('input', checkStep2Ready);
    });

    // 전화번호 숫자+특수문자만
    document.getElementById('phone').addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9\-\+\(\)\s]/g, '');
    });

    // 폼 제출 검증
    document.getElementById('regForm').addEventListener('submit', function(e) {
        const req1 = document.querySelector('input[name="agree_required_1"]').checked;
        const req2 = document.querySelector('input[name="agree_required_2"]').checked;
        const req3 = document.querySelector('input[name="agree_required_3"]').checked;
        if (!req1) { e.preventDefault(); alert('[필수] 아시아나클럽 일반 규정 및 홈페이지 이용 약관에 동의해주세요.'); return; }
        if (!req2) { e.preventDefault(); alert('[필수] 개인정보 수집 및 이용안내에 동의해주세요.'); return; }
        if (!req3) { e.preventDefault(); alert('[필수] 개인정보 국외 이전 동의에 동의해주세요.'); return; }
    });
});

function checkIdDup() {
    const userId = document.getElementById('user_id').value.trim();
    if (!userId) { alert('아이디를 먼저 입력해 주세요.'); return; }
    if (!/^[A-Za-z0-9]{6,12}$/.test(userId)) { alert('아이디는 6~12자리 영문, 숫자만 입력 가능합니다.'); return; }
    
    fetch('check_id.php?user_id=' + encodeURIComponent(userId))
        .then(response => response.json()) // 응답을 JSON 데이터로 파싱
        .then(data => {
            if (data.result === 'success') {
                alert(userId + '은(는) 사용 가능한 아이디입니다.');
                document.getElementById('user_id').dataset.checked = "Y";
            } else if (data.result === 'fail') {
                alert('이미 존재하는 아이디입니다. 다른 아이디를 입력해 주세요.');
                document.getElementById('user_id').value = '';
                document.getElementById('user_id').focus();
                document.getElementById('user_id').dataset.checked = "N";
            } else {
                alert('오류가 발생했습니다. 다시 시도해 주세요.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('서버 통신 중 오류가 발생했습니다.');
        });
}