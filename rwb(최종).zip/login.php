<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>로그인 - ASIANA AIRLINES</title>
  <link rel="stylesheet" href="css/reset.css">
  <link rel="stylesheet" href="css/login.css">
</head>
<body>
  <div class="login-container">
    <header class="login-header">
      <h1 class="logo"><a href="index.php"><img src="img/logo_m.png" alt="ASIANA AIRLINES"></a></h1>
      <h2 class="title">로그인</h2>
    </header>

    <main class="login-box">
      <div class="login-tabs">
        <button type="button" class="tab-btn active">로그인</button>
        <button type="button" class="tab-btn" onclick="alert('서비스 준비 중입니다.');">비로그인 예약조회</button>
      </div>

      <form class="login-form" action="login_process.php" method="POST">
        <div class="input-row">
          <label for="user_id" class="blind">아이디</label>
          <input type="text" id="user_id" name="user_id" placeholder="아이디" required>
        </div>
        
        <div class="input-row">
          <label for="user_pw" class="blind">비밀번호</label>
          <input type="password" id="user_pw" name="user_pw" placeholder="비밀번호" required>
        </div>

        <div class="login-utility">
          <label class="checkbox-label">
            <input type="checkbox" name="save_id" id="save_id">
            <span class="custom-checkbox"></span>
            <span class="label-text">아이디 저장</span>
          </label>
          <a href="register.php" class="link-text">회원가입</a>
        </div>

        <button type="submit" class="submit-btn">로그인</button>
      </form>

      <div class="find-links">
        <a href="#">아이디 찾기</a>
        <span class="divider"></span>
        <a href="#">회원번호 찾기</a>
        <span class="divider"></span>
        <a href="#">비밀번호 찾기</a>
      </div>

      <div class="sns-login-area">
        <p class="sns-title">SNS 간편 로그인</p>
        <div class="sns-icons">
          <a href="#" class="sns-item naver"><span class="sns-name"><img src="img/login_logo1.png" alt="logo1">네이버</span></a>
          <a href="#" class="sns-item kakao"><span class="sns-name"><img src="img/login_logo2.png" alt="logo2">카카오</span></a>
          <a href="#" class="sns-item line"><span class="sns-name"><img src="img/login_logo3.png" alt="logo3">라인</span></a>
          <a href="#" class="sns-item wechat"><span class="sns-name"><img src="img/login_logo4.png" alt="logo4">위챗</span></a>
          <a href="#" class="sns-item facebook"><span class="sns-name"><img src="img/login_logo5.png" alt="logo5">페이스북</span></a>
        </div>
      </div>
    </main>

    <footer class="login-footer">
      <div class="join-guide-box">
        <h3>아직 아시아나 회원이 아니세요?</h3>
        <p>회원으로 가입하시고<br>신규회원 혜택을 누려 보세요.</p>
        <a href="register.php" class="join-btn">회원가입</a>
      </div>
    </footer>
  </div>
</body>
</html>