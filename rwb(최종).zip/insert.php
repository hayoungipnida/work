<?php
// 1. 데이터베이스 연결 (본인의 DB 정보 입력)
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "내DB이름";

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die("DB 연결 실패: " . mysqli_connect_error());
}

// 2. 비밀번호 보안 암호화 (실무 필수)
// 입력한 비밀번호를 알아볼 수 없는 난수로 변경합니다.
$hashedPassword = password_hash($userPw, PASSWORD_DEFAULT);

// 3. 쿼리문 실행 중 에러가 나면 롤백할 수 있도록 트랜잭션 시작
mysqli_begin_transaction($conn);

try {
    // [SQL 1] 회원 기본 정보 테이블에 저장
    $sql1 = "INSERT INTO members (
                user_id, user_pw, last_name_eng, first_name_eng, 
                last_name_kor, first_name_kor, birth_date, gender, 
                phone, email, address
             ) VALUES (
                '$userId', '$hashedPassword', '$lastNameEng', '$firstNameEng', 
                '$lastNameKor', '$firstNameKor', '$birthDate', '$gender', 
                '$phone', '$email', '$address'
             )";
             
    if (!mysqli_query($conn, $sql1)) {
        throw new Exception("회원정보 등록 실패: " . mysqli_error($conn));
    }

    // 방금 생성된 회원의 고유 번호(member_idx) 가져오기
    $newMemberIdx = mysqli_insert_id($conn);

    // [SQL 2] 약관 동의 테이블에 저장
    $sql2 = "INSERT INTO member_terms (
                member_idx, agree_required_1, agree_required_2, agree_required_3, 
                agree_optional_1, agree_optional_2
             ) VALUES (
                $newMemberIdx, '$reqAgree1', '$reqAgree2', '$reqAgree3', 
                '$optAgree1', '$optAgree2'
             )";

    if (!mysqli_query($conn, $sql2)) {
        throw new Exception("약관동의 등록 실패: " . mysqli_error($conn));
    }

    // 두 테이블 모두 성공하면 최종 반영(Commit)
    mysqli_commit($conn);
    
    echo "<script>alert('회원가입이 성공적으로 완료되었습니다!'); location.href='register.php';</script>";

} catch (Exception $e) {
    // 하나라도 실패하면 가입 진행을 취소하고 되돌림(Rollback)
    mysqli_rollback($conn);
    echo "<script>alert('오류가 발생했습니다: " . $e->getMessage() . "'); history.back();</script>";
}

mysqli_close($conn);
?>