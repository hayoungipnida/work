<?php
// 1. 세션 데이터에 접근하기 위해 세션 시작
session_start();

// 2. 모든 세션 변수 지우기 (로그인 정보 제거)
$_SESSION = array();

// 3. 세션 쿠키가 사용되었다면 쿠키도 함께 삭제 (보안 강화)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 4. 세션 자체를 완전히 파괴
session_destroy();

// 5. 로그아웃 완료 알림창을 띄우고 메인 페이지(index.php)로 이동
echo "<script>
        alert('로그아웃 되었습니다.');
        location.href='index.php';
      </script>";
exit;
?>