<?php
// 1. 로그인 성공 기억상자(세션)를 열기 위해 파일 맨 위에 필수 선언
session_start();

// POST 방식으로 데이터가 넘어왔는지 확인
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // [1] 로그인 창에서 사용자가 입력한 값 가져오기
    $userId = trim($_POST['user_id'] ?? '');
    $userPw = trim($_POST['user_pw'] ?? '');

    // 만약 빈 값이 들어왔다면 튕겨내기
    if (empty($userId) || empty($userPw)) {
        echo "<script>alert('아이디와 비밀번호를 모두 입력해주세요.'); history.back();</script>";
        exit;
    }

    // [2] 데이터베이스 연결
    $db_host = "localhost";
    $db_user = "gnuoyah";
    $db_pass = "wjdgkdud1!";
    $db_name = "gnuoyah"; 

    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    if (!$conn) {
        die("DB 연결 실패: " . mysqli_connect_error());
    }

    // 💡 문자셋 설정 추가 (데이터 깨짐 방지 안전장치)
    mysqli_set_charset($conn, "utf8mb4");

    // SQL 인젝션 공격 방지를 위한 보안 처리
    $userId = mysqli_real_escape_string($conn, $userId);

    // [3] members 테이블에서 입력한 아이디와 일치하는 회원 정보 찾기
    $sql = "SELECT * FROM members WHERE user_id = '$userId'";
    $result = mysqli_query($conn, $sql);

    // [4] 아이디가 존재하는지 확인
    if ($row = mysqli_fetch_assoc($result)) {
        
        // [5] 회원가입할 때 암호화(password_hash)했던 비밀번호와 일치하는지 대조
        if (password_verify($userPw, $row['user_pw'])) {
            
            // 🔐 [핵심] 로그인 성공! 세션에 아이디 저장하기
            $_SESSION['user_id'] = $row['user_id']; 
            
            // 💡 이동하기 전에 안전하게 DB 연결을 먼저 닫아줍니다.
            mysqli_close($conn);
            
            // 마이페이지 아이콘이 작동할 메인 페이지(index.php)로 이동시킵니다.
            header("Location: index.php");
            exit;
            
        } else {
            // 비밀번호가 틀린 경우
            mysqli_close($conn); // DB 연결 닫기
            echo "<script>
                    alert('비밀번호가 일치하지 않습니다.'); 
                    history.back();
                  </script>";
            exit;
        }
        
    } else {
        // 아이디 자체가 없는 경우
        mysqli_close($conn); // DB 연결 닫기
        echo "<script>
                alert('존재하지 않는 아이디입니다.'); 
                history.back();
              </script>";
        exit;
    }

} else {
    // 만약 주소창에 직접 쳐서 비정상적으로 접근하면 로그인 페이지로 돌려보내기
    header("Location: login.php");
    exit;
}
?>